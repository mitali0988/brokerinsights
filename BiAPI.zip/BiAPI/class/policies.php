<?php
    class Policy{
        // Connection
        private $conn;
        // Table
        private $db_table = "bipolicies";
        // Columns
        public $id;
        public $client_name;
        public $name;
        public $address;
        public $premium;
        public $policy_type;
        public $insurer_name;
        public $created;
        public $searchText;
        // Db connection
        public function __construct($db){
            $this->conn = $db;
        }
        // GET ALL
        public function getPolicies(){
            $sqlQuery = "SELECT id, client_name, customer_name, customer_address, premium, policy_type, insurer_name, created FROM " . $this->db_table . "";
            $stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
        }
        // Search by text
        public function getSearchPolicy(){
            $sqlQuery = "SELECT
                        id, client_name, customer_name, customer_address, premium, policy_type, insurer_name, created
                      FROM
                        ". $this->db_table ."
                    WHERE 
                       customer_name like ?
                    ";
            $stmt = $this->conn->prepare($sqlQuery);
            $var1 = "%".$this->searchText."%";
            $stmt->bindParam(1, $var1);
            $stmt->execute();
            return $stmt;
        }
        // CREATE
        public function createPolicy(){
            $sqlQuery = "INSERT INTO
                        ". $this->db_table ."
                    SET
                        client_name = :client_name,
                        customer_name = :name, 
                        customer_address = :address, 
                        premium = :premium, 
                        policy_type = :policy_type,
                        insurer_name= :insurer_name, 
                        created = :created";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            // sanitize
            $this->client_name=htmlspecialchars(strip_tags($this->client_name));
            $this->name=htmlspecialchars(strip_tags($this->name));
            $this->address=htmlspecialchars(strip_tags($this->address));
            $this->premium=htmlspecialchars(strip_tags($this->premium));
            $this->policy_type=htmlspecialchars(strip_tags($this->policy_type));
            $this->insurer_name=htmlspecialchars(strip_tags($this->insurer_name));
            $this->created=htmlspecialchars(strip_tags($this->created));
            // bind data
            $stmt->bindParam(":client_name", $this->client_name);
            $stmt->bindParam(":name", $this->name);
            $stmt->bindParam(":address", $this->address);
            $stmt->bindParam(":premium", $this->premium);
            $stmt->bindParam(":policy_type", $this->policy_type);
            $stmt->bindParam(":insurer_name", $this->insurer_name);
            $stmt->bindParam(":created", $this->created);

            if($stmt->execute()){
               return true;
            }
            return false;
        }
        // READ single
        public function getSinglePolicy(){
            $sqlQuery = "SELECT
                        id, client_name, customer_name, customer_address, premium, policy_type, insurer_name, created
                      FROM
                        ". $this->db_table ."
                    WHERE 
                       id = ?
                    LIMIT 0,1";
            $stmt = $this->conn->prepare($sqlQuery);
            $stmt->bindParam(1, $this->id);
            $stmt->execute();
            $dataRow = $stmt->fetch(PDO::FETCH_ASSOC);
            $this->client_name = $dataRow['client_name'];
            $this->name = $dataRow['customer_name'];
            $this->address = $dataRow['customer_address'];
            $this->premium = $dataRow['premium'];
            $this->policy_type = $dataRow['policy_type'];
            $this->insurer_name = $dataRow['insurer_name'];
            $this->created = $dataRow['created'];
        }        
        // UPDATE
        public function updatePolicy(){
            $sqlQuery = "UPDATE
                        ". $this->db_table ."
                    SET
                        customer_name = :name, 
                        customer_address = :address, 
                        premium = :premium, 
                        policy_type = :policy_type,
                        insurer_name= :insurer_name, 
                        created = :created
                    WHERE 
                        id = :id";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->name=htmlspecialchars(strip_tags($this->name));
            $this->address=htmlspecialchars(strip_tags($this->address));
            $this->premium=htmlspecialchars(strip_tags($this->premium));
            $this->policy_type=htmlspecialchars(strip_tags($this->policy_type));
            $this->insurer_name=htmlspecialchars(strip_tags($this->insurer_name));
            $this->created=htmlspecialchars(strip_tags($this->created));
            $this->id=htmlspecialchars(strip_tags($this->id));

        
            // bind data

            $stmt->bindParam(":name", $this->name);
            $stmt->bindParam(":address", $this->address);
            $stmt->bindParam(":premium", $this->premium);
            $stmt->bindParam(":policy_type", $this->policy_type);
            $stmt->bindParam(":insurer_name", $this->insurer_name);
            $stmt->bindParam(":created", $this->created);
            $stmt->bindParam(":id", $this->id);

            if($stmt->execute()){
               return true;
            }
            return false;
        }
        // DELETE
        function deletePolicy(){
            $sqlQuery = "DELETE FROM " . $this->db_table . " WHERE id = ?";
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->id=htmlspecialchars(strip_tags($this->id));
        
            $stmt->bindParam(1, $this->id);
        
            if($stmt->execute()){
                return true;
            }
            return false;
        }
    }
?>