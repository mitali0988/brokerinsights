<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    
    include_once '../config/database.php';
    include_once '../class/policies.php';
    $database = new Database();
    $db = $database->getConnection();
    $items = new Policy($db);
    $stmt = $items->getPolicies();
    $itemCount = $stmt->rowCount();

    if($itemCount > 0){
        
        $policyArr = array();
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $e = array(
                "id" => $id,
                "client_name" => $client_name,
                "name" => $customer_name,
                "address" => $customer_address,
                "premium" => $premium,
                "policy_type" => $policy_type,
                "insurer_name" => $insurer_name,
                "created" => $created
            );
            array_push($policyArr, $e);
        }
        echo json_encode($policyArr);
    }
    else{
        http_response_code(404);
        echo json_encode(
            array("message" => "No record found.")
        );
    }
?>