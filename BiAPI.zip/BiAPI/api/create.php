<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    include_once '../config/database.php';
    include_once '../class/policies.php';
    $database = new Database();
    $db = $database->getConnection();
    $item = new Policy($db);
    $data = json_decode(file_get_contents("php://input"));
    $item->client_name = $data->client_name;
    $item->name = $data->name;
    $item->address = $data->address;
    $item->premium = $data->premium;
    $item->policy_type = $data->policy_type;
    $item->insurer_name = $data->insurer_name;
    $item->created = date('Y-m-d H:i:s');
    
    if($item->createPolicy()){
        echo 'Policy created successfully.';
    } else{
        echo 'Policy could not be created.';
    }
?>
