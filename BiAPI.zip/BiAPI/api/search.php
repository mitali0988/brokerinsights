<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    include_once '../config/database.php';
    include_once '../class/policies.php';
    $database = new Database();
    $db = $database->getConnection();
    $item = new Policy($db);
    $item->searchText = isset($_GET['text']) ? $_GET['text'] : die();
  
    $stmt = $item->getSearchPolicy();
    $itemCount = $stmt->rowCount();

    if($itemCount > 0){
        
        $policyArr = array();
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $e = array(
                "id" => $id,
                "client_name" => $client_name,
                "name" => $customer_name,
                "address" => $customer_address,
                "premium" => $premium,
                "policy_type" => $policy_type,
                "insurer_name" => $insurer_name,
                "created" => $created
            );
            array_push($policyArr, $e);
        }
        echo json_encode($policyArr);
    }
    else{
        http_response_code(404);
        echo json_encode(
            array("message" => "No record found.")
        );
    }
?>